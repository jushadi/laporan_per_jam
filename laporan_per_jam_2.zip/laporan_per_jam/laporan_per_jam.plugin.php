<?php
/**
 * Plugin Name: Laporan Kunjungan vs Transaksi per Jam
 * Plugin URI: -
 * Description: Menampilkan laporan perbandingan jumlah pengunjung dan transaksi peminjaman per jam pada tanggal yang dipilih.
 * Version: 1.0.0
 * Author: Jushadi Arman Saz
 * Author URI: #
 */

// masukan file ini ke folder "plugins/laporan_per_jam/"

// get plugin instance
$plugin = \SLiMS\Plugins::getInstance();

// register plugin
$plugin->registerMenu('reporting', 'Laporan per Jam', __DIR__ . '/index.php');