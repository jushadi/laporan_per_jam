<?php
/**
 * Plugin Laporan per Jam - Gaya Report SLiMS dengan Grafik (Jam Kerja)
 * @Author: Jushadi Arman Saz
 * @Date: 2025-08-16
 */

defined('INDEX_AUTH') OR die('Direct access not allowed!');

// Pengecekan sesi dan hak akses
require SB . 'admin/default/session.inc.php';
require SB . 'admin/default/session_check.inc.php';
require LIB . 'ip_based_access.inc.php';
do_checkIP('smc');
do_checkIP('smc-reporting');

// Memuat library yang dibutuhkan
require SIMBIO . 'simbio_GUI/table/simbio_table.inc.php';
require SIMBIO . 'simbio_GUI/form_maker/simbio_form_table_AJAX.inc.php';
require SIMBIO . 'simbio_GUI/paging/simbio_paging.inc.php';
require SIMBIO . 'simbio_DB/datagrid/simbio_dbgrid.inc.php';
require MDLBS . 'reporting/report_dbgrid.inc.php';

// Pengecekan hak akses (privilege)
$can_read = utility::havePrivilege('reporting', 'r');
if (!$can_read) {
    die('<div class="errorBox">' . __('You are not authorized to view this section') . '</div>');
}

function httpQuery($query = [])
{
    // Hapus parameter reportView dari query string agar tidak duplikat
    unset($_GET['reportView']);
    return http_build_query(array_unique(array_merge($_GET, $query)));
}

$page_title = 'Laporan Kunjungan vs. Transaksi per Jam';
$reportView = false;
$num_recs_show = 24; // Tetap 24 untuk memastikan semua data jam kerja muncul

if (isset($_GET['reportView'])) {
    $reportView = true;
}

// Set tanggal default ke hari ini jika tidak ada input dari form
$tanggal_laporan = isset($_GET['report_date']) ? utility::filterData('report_date', 'get', true, true, true) : date('Y-m-d');

if (!$reportView) {
?>
<div class="per_title">
    <h2><?php echo $page_title; ?></h2>
</div>
<div class="infoBox">
    Silakan pilih tanggal untuk melihat perbandingan jumlah pengunjung dengan jumlah transaksi peminjaman per jam (07:00 - 17:00).
</div>
<div class="sub_section">
    <form method="get" action="<?= $_SERVER['PHP_SELF'] . '?' . httpQuery(); ?>" target="reportView">
        <input type="hidden" name="id" value="<?= $_GET['id'] ?>"/>
        <input type="hidden" name="mod" value="<?= $_GET['mod'] ?>"/>
        <div id="filterForm">
            <div class="form-group divRow">
                <label><?php echo __('Pilih Tanggal Laporan'); ?></label>
                <?php
                echo simbio_form_element::dateField('report_date', $tanggal_laporan, 'class="form-control"');
                ?>
            </div>
        </div>
        <input type="submit" name="applyFilter" class="btn btn-primary" value="<?php echo __('Tampilkan Laporan'); ?>" />
        <input type="hidden" name="reportView" value="true" />
    </form>
</div>
<div class="sub_section">
    <div class="card">
        <div class="card-header">Grafik Laporan</div>
        <div class="card-body" style="position: relative; height: 350px;">
            <canvas id="grafikLaporan"></canvas>
        </div>
    </div>
</div>

<div class="paging-area"><div class="pt-3 pr-3" id="pagingBox"></div></div>

<iframe name="reportView" id="reportView" src="about:blank" frameborder="0" style="width: 100%; height: 600px;"></iframe>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    let grafikLaporanChart; // Variabel global untuk grafik

    function gambarGrafik(labels, dataKunjungan, dataTransaksi) {
        const ctx = document.getElementById('grafikLaporan').getContext('2d');
        
        if (grafikLaporanChart) {
            grafikLaporanChart.destroy();
        }

        grafikLaporanChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Jumlah Pengunjung',
                    data: dataKunjungan,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }, {
                    label: 'Jumlah Transaksi',
                    data: dataTransaksi,
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false, 
                scales: {
                    y: { beginAtZero: true }
                },
                animation: {
                    duration: 0 
                }
            }
        });
    }

    // Muat laporan secara otomatis saat halaman pertama kali dibuka
    document.addEventListener("DOMContentLoaded", function() {
        document.querySelector('form[target="reportView"]').submit();
    });
</script>

<?php
} else {
    // Tampilan Hasil Laporan di dalam Iframe
    ob_start();
    
    // === PERUBAHAN DI SINI ===
    // Menggunakan Jam Operasional dari jam 7 hingga 17
    $sql_grafik = "WITH JamOperasional AS (SELECT 7 AS Pukul UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10 UNION ALL SELECT 11 UNION ALL SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14 UNION ALL SELECT 15 UNION ALL SELECT 16 UNION ALL SELECT 17) SELECT CONCAT(LPAD(J.Pukul, 2, '0'), ':00') AS Jam, COALESCE(K.TotalKunjungan, 0) AS Jumlah_Pengunjung, COALESCE(T.TotalTransaksi, 0) AS Jumlah_Transaksi_Peminjaman FROM JamOperasional AS J LEFT JOIN (SELECT HOUR(checkin_date) AS Pukul, COUNT(1) AS TotalKunjungan FROM visitor_count WHERE DATE(checkin_date) = '{$tanggal_laporan}' GROUP BY Pukul) AS K ON J.Pukul = K.Pukul LEFT JOIN (SELECT HOUR(input_date) AS Pukul, COUNT(1) AS TotalTransaksi FROM loan WHERE DATE(input_date) = '{$tanggal_laporan}' GROUP BY Pukul) AS T ON J.Pukul = T.Pukul ORDER BY J.Pukul ASC";
    
    $koneksi = $dbs->query($sql_grafik);
    $data_laporan = [];
    while ($row = $koneksi->fetch_assoc()) {
        $data_laporan[] = $row;
    }

    $table_spec = "( {$sql_grafik} ) AS report_data";

    $reportgrid = new report_datagrid();
    $reportgrid->table_attr = 'class="s-table table table-sm table-bordered"';
    $reportgrid->setSQLColumn('Jam, `Jumlah_Pengunjung`, `Jumlah_Transaksi_Peminjaman`');
    $reportgrid->setSQLorder('Jam ASC');
    $reportgrid->show_spreadsheet_export = true;
    
    echo '<div class="h5 my-3">Laporan untuk Tanggal: <strong>' . $tanggal_laporan . '</strong></div>';
    echo $reportgrid->createDataGrid($dbs, $table_spec, $num_recs_show);

    $labels_grafik = json_encode(array_column($data_laporan, 'Jam'));
    $data_kunjungan_grafik = json_encode(array_column($data_laporan, 'Jumlah_Pengunjung'));
    $data_transaksi_grafik = json_encode(array_column($data_laporan, 'Jumlah_Transaksi_Peminjaman'));

    echo '<script type="text/javascript">'."\n";
    echo 'parent.$(\'#pagingBox\').html(\''.str_replace(array("\n", "\r", "\t"), '', $reportgrid->paging_set).'\');'."\n";
    echo 'if (window.parent && typeof window.parent.gambarGrafik === "function") {'."\n";
    echo '    parent.gambarGrafik('.$labels_grafik.', '.$data_kunjungan_grafik.', '.$data_transaksi_grafik.');'."\n";
    echo '}'."\n";
    echo '</script>';
    
    $xlsquery = "SELECT Jam, `Jumlah_Pengunjung` AS 'Jumlah Pengunjung', `Jumlah_Transaksi_Peminjaman` AS 'Jumlah Transaksi Peminjaman' FROM {$table_spec}";
    unset($_SESSION['xlsdata']);
    $_SESSION['xlsquery'] = $xlsquery;
    $_SESSION['tblout'] = "Laporan_Per_Jam_" . $tanggal_laporan;
    
    $content = ob_get_clean();
    require SB.'/admin/'.$sysconf['admin_template']['dir'].'/printed_page_tpl.php';
}